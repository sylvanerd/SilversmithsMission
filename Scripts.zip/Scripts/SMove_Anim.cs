using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SMove_Anim : MonoBehaviour
{
    public GameObject Intro;


    // Update is called once per frame
    public void PlayIntro1Anim()
    {
    }

}
